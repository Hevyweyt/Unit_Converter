const tabs = document.querySelectorAll('.tab');
const contents = document.querySelectorAll('.tab-content');

tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    tabs.forEach(t => t.classList.remove('active'));
    contents.forEach(c => c.classList.remove('active'));
    tab.classList.add('active');
    document.getElementById(tab.dataset.tab).classList.add('active');
  });
});

const unitInput = document.getElementById('unitInput');
const unitFrom = document.getElementById('unitFrom');
const unitTo = document.getElementById('unitTo');
const unitResult = document.getElementById('unitResult');

const unitMap = {
  'Nanosecond (ns)': 1e-9,
  'Microsecond (µs)': 1e-6,
  'Millisecond (ms)': 0.001,
  'Second (s)': 1,
  'Minute (min)': 60,
  'Hour (h)': 3600,
  'Day (d)': 86400,
  'Millimeter (mm)': 0.001,
  'Centimeter (cm)': 0.01,
  'Meter (m)': 1,
  'Kilometer (km)': 1000,
  'Inch (in)': 0.0254,
  'Foot (ft)': 0.3048,
  'Yard (yd)': 0.9144,
  'Mile (mi)': 1609.34,
  'Gram (g)': 0.001,
  'Kilogram (kg)': 1,
  'Metric Ton (t)': 1000,
  'Pound (lb)': 0.453592,
  'Ounce (oz)': 0.0283495,
  'Milliliter (mL)': 0.001,
  'Liter (L)': 1,
  'Cubic meter (m³)': 1000,
  'Gallon (US)': 3.78541,
  'Pint (US)': 0.473176,
  'Newton (N)': 1,
  'Joule (J)': 1,
  'Watt (W)': 1,
  'Pascal (Pa)': 1,
  'Ampere (A)': 1,
  'Volt (V)': 1,
  'Coulomb (C)': 1,
  'Ohm (Ω)': 1,
  'Farad (F)': 1,
  'Henry (H)': 1,
  'Tesla (T)': 1,
  'Lux (lx)': 1,
  'Hertz (Hz)': 1,
  'Mole (mol)': 1,
  'Decibel (dB)': 1,
  'Celsius (C)': 'temp',
  'Fahrenheit (F)': 'temp',
  'Kelvin (K)': 'temp'
};

for (let key in unitMap) {
  unitFrom.innerHTML += `<option value="${key}">${key}</option>`;
  unitTo.innerHTML += `<option value="${key}">${key}</option>`;
}

function convertUnits() {
  const val = parseFloat(unitInput.value);
  const from = unitFrom.value;
  const to = unitTo.value;

  if (isNaN(val)) return unitResult.innerText = 'Enter a valid number';
  if (unitMap[from] === 'temp' || unitMap[to] === 'temp') {
    return unitResult.innerText = convertTemp(val, from, to);
  }
  const result = val * (unitMap[from] / unitMap[to]);
  unitResult.innerText = `Result: ${result.toFixed(4)}`;
}

function convertTemp(value, from, to) {
  let k;
  if (from === 'Celsius (C)') k = value + 273.15;
  else if (from === 'Fahrenheit (F)') k = (value - 32) * 5/9 + 273.15;
  else k = value;

  let result;
  if (to === 'Celsius (C)') result = k - 273.15;
  else if (to === 'Fahrenheit (F)') result = (k - 273.15) * 9/5 + 32;
  else result = k;

  return `Result: ${result.toFixed(2)}`;
}

unitInput.addEventListener('input', convertUnits);
unitFrom.addEventListener('change', convertUnits);
unitTo.addEventListener('change', convertUnits);

const currencyInput = document.getElementById('currencyInput');
const currencyFrom = document.getElementById('currencyFrom');
const currencyTo = document.getElementById('currencyTo');
const currencyResult = document.getElementById('currencyResult');

async function fetchCurrencies() {
  const res = await fetch('https://api.frankfurter.app/currencies');
  const data = await res.json();
  for (let code in data) {
    currencyFrom.innerHTML += `<option value="${code}">${code}</option>`;
    currencyTo.innerHTML += `<option value="${code}">${code}</option>`;
  }
}

async function convertCurrency() {
  const amount = currencyInput.value;
  const from = currencyFrom.value;
  const to = currencyTo.value;
  if (from === to) return currencyResult.innerText = `Result: ${amount}`;
  const res = await fetch(`https://api.frankfurter.app/latest?amount=${amount}&from=${from}&to=${to}`);
  const data = await res.json();
  currencyResult.innerText = `Result: ${data.rates[to].toFixed(2)} ${to}`;
}

currencyInput.addEventListener('input', convertCurrency);
currencyFrom.addEventListener('change', convertCurrency);
currencyTo.addEventListener('change', convertCurrency);

fetchCurrencies();